import random
import time
import pygame

pygame.init()

gameDisplay = pygame.display.set_mode((830,600))
pygame.display.set_caption('A-L-P-H-A-N-U-M-P-U-Z-Z-L-E')
blue = (0,0,255)
green = (0,255,0)
gameType ='abc'
def GameExit():
    pygame.quit()
    quit()
true = True
def BREAK():
    global true
    true = False
def gamePlay():
   global gameType 
   C1= 150
   C2 = 300
   C3= 450

   x1 = C1
   x2 = C2
   x3 = C3
   x4 = C1
   x5 = C2
   x6 = C3
   x7 = C1
   x8 = C2
   x9 = C3

   y1 = C1
   y2 = C1
   y3 = C1
   y4 = C2
   y5 = C2
   y6 = C2
   y7 = C3
   y8 = C3
   y9 = C3
   movement = 0
   font = pygame.font.SysFont("comicsansms",40)
   print(gameType)
   while True:
        gameDisplay.fill((60,180,100))
        pygame.draw.rect(gameDisplay,blue,(x1,y1,100,100))
        pygame.draw.rect(gameDisplay,blue,(x2,y2,100,100))
        pygame.draw.rect(gameDisplay,(255,255,255),(x3,y3,100,100))
        pygame.draw.rect(gameDisplay,blue,(x4,y4,100,100))
        pygame.draw.rect(gameDisplay,blue,(x5,y5,100,100))
        pygame.draw.rect(gameDisplay,blue,(x6,y6,100,100))
        pygame.draw.rect(gameDisplay,blue,(x7,y7,100,100))
        pygame.draw.rect(gameDisplay,blue,(x8,y8,100,100))
        pygame.draw.rect(gameDisplay,blue,(x9,y9,100,100))

        font = pygame.font.SysFont("comicsansms",80)
        if gameType == 'numPuzzle':
            text = font.render('NUMBER-PUZZLE',True,(255,0,255))
            gameDisplay.blit(text,(90,0))
            text = font.render('6',True,green)
            gameDisplay.blit(text,(x1+20,y1-10))
            text = font.render('4',True,green)
            gameDisplay.blit(text,(x2+20,y2-10))
            text = font.render('2',True,green)
            gameDisplay.blit(text,(x4+20,y4-10))
            text = font.render('7',True,green)
            gameDisplay.blit(text,(x5+20,y5-10))
            text = font.render('8',True,green)
            gameDisplay.blit(text,(x6+20,y6-10))
            text = font.render('3',True,green)
            gameDisplay.blit(text,(x7+20,y7-10))
            text = font.render('1',True,green)
            gameDisplay.blit(text,(x8+20,y8-10))
            text = font.render('5',True,green)
            gameDisplay.blit(text,(x9+20,y9-10))
            targetNum()
            numResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9)
        elif gameType == 'alphaPuzzle':
            text = font.render('ALPHABET-PUZZLE',True,(255,0,255))
            gameDisplay.blit(text,(40,0))
            text = font.render('H',True,green)
            gameDisplay.blit(text,(x1+20,y1-10))
            text = font.render('A',True,green)
            gameDisplay.blit(text,(x2+20,y2-10))
            text = font.render('B',True,green)
            gameDisplay.blit(text,(x4+20,y4-10))
            text = font.render('D',True,green)
            gameDisplay.blit(text,(x5+20,y5-10))
            text = font.render('G',True,green)
            gameDisplay.blit(text,(x6+20,y6-10))
            text = font.render('C',True,green)
            gameDisplay.blit(text,(x7+20,y7-10))
            text = font.render('F',True,green)
            gameDisplay.blit(text,(x8+20,y8-10))
            text = font.render('E',True,green)
            gameDisplay.blit(text,(x9+20,y9-10))
            targetAlpha()
            alphaResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9)
        else:
            text = font.render('ALPHA-NUM-PUZZLE',True,(255,0,255))
            gameDisplay.blit(text,(0,0))
            text = font.render('A',True,green)
            gameDisplay.blit(text,(x1+20,y1-10))
            text = font.render('4',True,green)
            gameDisplay.blit(text,(x2+20,y2-10))
            text = font.render('B',True,green)
            gameDisplay.blit(text,(x4+20,y4-10))
            text = font.render('3',True,green)
            gameDisplay.blit(text,(x5+20,y5-10))
            text = font.render('C',True,green)
            gameDisplay.blit(text,(x6+20,y6-10))
            text = font.render('2',True,green)
            gameDisplay.blit(text,(x7+20,y7-10))
            text = font.render('D',True,green)
            gameDisplay.blit(text,(x8+20,y8-10))
            text = font.render('1',True,green)
            gameDisplay.blit(text,(x9+20,y9-10))
            targetNumAlpha()
            alphaNumResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9)
        font = pygame.font.SysFont("comicsansms",40)
        text = font.render('MOVES::'+str(movement),True,(255,0,0))
        gameDisplay.blit(text,(590,150))
        if movement == 100:
            pygame.display.update()
            time.sleep(1)
            gameOver()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_HOME:
                    global true
                    font = pygame.font.SysFont("comicsansms",30)
                    gray = pygame.image.load('gray.png')
                    while true:
                        for event in pygame.event.get():
                            if event.type == pygame.QUIT:
                                GameExit()
                        gameDisplay.blit(gray,(550,100))
                        text = font.render('do you want to quit',True,(160,20,82))
                        gameDisplay.blit(text,(560,180))
                        button('YES',650,260,115,60,red,green,gameIntro)
                        button('NO',650,380,92,60,red,green,BREAK)
                        pygame.display.update()
                    true = True
                elif event.key == pygame.K_LEFT:
                    background_crash()
                    x3-=150
                    movement+=1
                    if x3<C1:
                        movement-=1
                        x3+=150
                    if x3 == C2 and y3 == C1:   
                        if x1 == C2 and y1 == C1:
                            x1 = C3
                        elif x2 == C2 and y2 == C1:
                            x2 = C3
                        elif x4 == C2 and y4 == C1:
                            x4 = C3
                        elif x5 == C2 and y5 == C1:
                            x5 = C3
                        elif x6 == C2 and y6 == C1:
                            x6 = C3
                        elif x7 == C2 and y7 == C1:
                            x7 = C3
                        elif x8 == C2 and y8 == C1:
                            x8 = C3
                        elif x9 == C2 and y9 == C1:
                            x9 = C3
                    elif x3 == C1 and y3 == C1:
                        if x1 == C1 and y1 == C1:
                            x1 = C2
                        elif x2 == C1 and y2 == C1:
                            x2 = C2
                        elif x4 == C1 and y4 == C1:
                            x4 = C2
                        elif x5 == C1 and y5 == C1:
                            x5 = C2
                        elif x6 == C1 and y6 == C1:
                            x6 = C2
                        elif x7 == C1 and y7 == C1:
                            x7 = C2
                        elif x8 == C1 and y8 == C1:
                            x8 = C2
                        elif x9 == C1 and y9 == C1:
                            x9 = C2                    

                    elif x3 == C2 and y3 == C2:   
                        if x1 == C2 and y1 == C2:
                            x1 = C3
                        elif x2 == C2 and y2 == C2:
                            x2 = C3
                        elif x4 == C2 and y4 == C2:
                            x4 = C3
                        elif x5 == C2 and y5 == C2:
                            x5 = C3
                        elif x6 == C2 and y6 == C2:
                            x6 = C3
                        elif x7 == C2 and y7 == C2:
                            x7 = C3
                        elif x8 == C2 and y8 == C2:
                            x8 = C3
                        elif x9 == C2 and y9 == C2:
                            x9 = C3
                    elif x3 == C1 and y3 == C2:
                        if x1 == C1 and y1 == C2:
                            x1 = C2
                        elif x2 == C1 and y2 == C2:
                            x2 = C2
                        elif x4 == C1 and y4 == C2:
                            x4 = C2
                        elif x5 == C1 and y5 == C2:
                            x5 = C2
                        elif x6 == C1 and y6 == C2:
                            x6 = C2
                        elif x7 == C1 and y7 == C2:
                            x7 = C2
                        elif x8 == C1 and y8 == C2:
                            x8 = C2
                        elif x9 == C1 and y9 == C2:
                            x9 = C2                   

                    elif x3 == C2 and y3 == C3:   
                        if x1 == C2 and y1 == C3:
                            x1 = C3
                        elif x2 == C2 and y2 == C3:
                            x2 = C3
                        elif x4 == C2 and y4 == C3:
                            x4 = C3
                        elif x5 == C2 and y5 == C3:
                            x5 = C3
                        elif x6 == C2 and y6 == C3:
                            x6 = C3
                        elif x7 == C2 and y7 == C3:
                            x7 = C3
                        elif x8 == C2 and y8 == C3:
                            x8 = C3
                        elif x9 == C2 and y9 == C3:
                            x9 = C3
                    elif x3 == C1 and y3 == C3:
                        if x1 == C1 and y1 == C3:
                            x1 = C2
                        elif x2 == C1 and y2 == C3:
                            x2 = C2
                        elif x4 == C1 and y4 == C3:
                            x4 = C2
                        elif x5 == C1 and y5 == C3:
                            x5 = C2
                        elif x6 == C1 and y6 == C3:
                            x6 = C2
                        elif x7 == C1 and y7 == C3:
                            x7 = C2
                        elif x8 == C1 and y8 == C3:
                            x8 = C2
                        elif x9 == C1 and y9 == C3:
                            x9 = C2                    
                elif event.key == pygame.K_RIGHT:
                    background_crash()
                    x3+=150
                    movement+=1
                    if x3>C3:
                        movement-=1
                        x3-=150
                    if x3 == C2 and y3 == C1:   
                        if x1 == C2 and y1 == C1:
                            x1 = C1
                        elif x2 == C2 and y2 == C1:
                            x2 = C1
                        elif x4 == C2 and y4 == C1:
                            x4 = C1
                        elif x5 == C2 and y5 == C1:
                            x5 = C1
                        elif x6 == C2 and y6 == C1:
                            x6 = C1
                        elif x7 == C2 and y7 == C1:
                            x7 = C1
                        elif x8 == C2 and y8 == C1:
                            x8 = C1
                        elif x9 == C2 and y9 == C1:
                            x9 = C1
                    elif x3 == C3 and y3 == C1:
                        if x1 == C3 and y1 == C1:
                            x1 = C2
                        elif x2 == C3 and y2 == C1:
                            x2 = C2
                        elif x4 == C3 and y4 == C1:
                            x4 = C2
                        elif x5 == C3 and y5 == C1:
                            x5 = C2
                        elif x6 == C3 and y6 == C1:
                            x6 = C2
                        elif x7 == C3 and y7 == C1:
                            x7 = C2
                        elif x8 == C3 and y8 == C1:
                            x8 = C2
                        elif x9 == C3 and y9 == C1:
                            x9 = C2                    

                    elif x3 == C2 and y3 == C2:  
                        if x1 == C2 and y1 == C2:
                            x1 = C1
                        elif x2 == C2 and y2 == C2:
                            x2 = C1
                        elif x4 == C2 and y4 == C2:
                            x4 = C1
                        elif x5 == C2 and y5 == C2:
                            x5 = C1
                        elif x6 == C2 and y6 == C2:
                            x6 = C1
                        elif x7 == C2 and y7 == C2:
                            x7 = C1
                        elif x8 == C2 and y8 == C2:
                            x8 = C1
                        elif x9 == C2 and y9 == C2:
                            x9 = C1
                    elif x3 == C3 and y3 == C2:
                        if x1 == C3 and y1 == C2:
                            x1 = C2
                        elif x2 == C3 and y2 == C2:
                            x2 = C2
                        elif x4 == C3 and y4 == C2:
                            x4 = C2
                        elif x5 == C3 and y5 == C2:
                            x5 = C2
                        elif x6 == C3 and y6 == C2:
                            x6 = C2
                        elif x7 == C3 and y7 == C2:
                            x7 = C2
                        elif x8 == C3 and y8 == C2:
                            x8 = C2
                        elif x9 == C3 and y9 == C2:
                            x9 = C2                    

                    elif x3 == C2 and y3 == C3:   
                        if x1 == C2 and y1 == C3:
                            x1 = C1
                        elif x2 == C2 and y2 == C3:
                            x2 = C1
                        elif x4 == C2 and y4 == C3:
                            x4 = C1
                        elif x5 == C2 and y5 == C3:
                            x5 = C1
                        elif x6 == C2 and y6 == C3:
                            x6 = C1
                        elif x7 == C2 and y7 == C3:
                            x7 = C1
                        elif x8 == C2 and y8 == C3:
                            x8 = C1
                        elif x9 == C2 and y9 == C3:
                            x9 = C1
                    elif x3 == C3 and y3 == C3:
                        if x1 == C3 and y1 == C3:
                            x1 = C2
                        elif x2 == C3 and y2 == C3:
                            x2 = C2
                        elif x4 == C3 and y4 == C3:
                            x4 = C2
                        elif x5 == C3 and y5 == C3:
                            x5 = C2
                        elif x6 == C3 and y6 == C3:
                            x6 = C2
                        elif x7 == C3 and y7 == C3:
                            x7 = C2
                        elif x8 == C3 and y8 == C3:
                            x8 = C2
                        elif x9 == C3 and y9 == C3:
                            x9 = C2                   

                elif event.key == pygame.K_DOWN:
                    background_crash()
                    y3+=150
                    movement+=1
                    if y3>C3:
                        movement-=1
                        y3-=150
                    if y3 == C2 and x3 == C1:  
                        if x1 == C1 and y1 == C2:
                            y1 = C1
                        elif x2 == C1 and y2 == C2:
                            y2 = C1
                        elif x4 == C1 and y4 == C2:
                            y4 = C1
                        elif x5 == C1 and y5 == C2:
                            y5 = C1
                        elif x6 == C1 and y6 == C2:
                            y6 = C1
                        elif x7 == C1 and y7 == C2:
                            y7 = C1
                        elif x8 == C1 and y8 == C2:
                            y8 = C1
                        elif x9 == C1 and y9 == C2:
                            y9 = C1
                    elif y3 == C3 and x3 == C1:   
                        if x1 == C1 and y1 == C3:
                            y1 = C2
                        elif x2 == C1 and y2 == C3:
                            y2 = C2
                        elif x4 == C1 and y4 == C3:
                            y4 = C2
                        elif x5 == C1 and y5 == C3:
                            y5 = C2
                        elif x6 == C1 and y6 == C3:
                            y6 = C2
                        elif x7 == C1 and y7 == C3:
                            y7 = C2
                        elif x8 == C1 and y8 == C3:
                            y8 =C2 
                        elif x9 == C1 and y9 == C3:
                            y9 = C2                       

                    elif y3 == C2 and x3 == C2:   
                        if x1 == C2 and y1 == C2:
                            y1 = C1
                        elif x2 == C2 and y2 == C2:
                            y2 = C1
                        elif x4 == C2 and y4 == C2:
                            y4 = C1
                        elif x5 == C2 and y5 == C2:
                            y5 = C1
                        elif x6 == C2 and y6 == C2:
                            y6 = C1
                        elif x7 == C2 and y7 == C2:
                            y7 = C1
                        elif x8 == C2 and y8 == C2:
                            y8 = C1
                        elif x9 == C2 and y9 == C2:
                            y9 = C1
                    elif y3 == C3 and x3 == C2:   
                        if x1 == C2 and y1 == C3:
                            y1 = C2
                        elif x2 == C2 and y2 == C3:
                            y2 = C2
                        elif x4 == C2 and y4 == C3:
                            y4 = C2
                        elif x5 == C2 and y5 == C3:
                            y5 = C2
                        elif x6 == C2 and y6 == C3:
                            y6 = C2
                        elif x7 == C2 and y7 == C3:
                            y7 = C2
                        elif x8 == C2 and y8 == C3:
                            y8 =C2 
                        elif x9 == C2 and y9 == C3:
                            y9 = C2                       

                    elif y3 == C2 and x3 == C3:  
                        if x1 == C3 and y1 == C2:
                            y1 = C1
                        elif x2 == C3 and y2 == C2:
                            y2 = C1
                        elif x4 == C3 and y4 == C2:
                            y4 = C1
                        elif x5 == C3 and y5 == C2:
                            y5 = C1
                        elif x6 == C3 and y6 == C2:
                            y6 = C1
                        elif x7 == C3 and y7 == C2:
                            y7 = C1
                        elif x8 == C3 and y8 == C2:
                            y8 = C1
                        elif x9 == C3 and y9 == C2:
                            y9 = C1
                    elif y3 == C3 and x3 == C3:   
                        if x1 == C3 and y1 == C3:
                            y1 = C2
                        elif x2 == C3 and y2 == C3:
                            y2 = C2
                        elif x4 == C3 and y4 == C3:
                            y4 = C2
                        elif x5 == C3 and y5 == C3:
                            y5 = C2
                        elif x6 == C3 and y6 == C3:
                            y6 = C2
                        elif x7 == C3 and y7 == C3:
                            y7 = C2
                        elif x8 == C3 and y8 == C3:
                            y8 =C2 
                        elif x9 == C3 and y9 == C3:
                            y9 = C2                     

                elif event.key == pygame.K_UP:
                    background_crash()
                    y3-=150
                    movement+=1
                    if y3<C1:
                        movement-=1
                        y3+=150
                    if y3 == C2 and x3 == C1:  
                        if x1 == C1 and y1 == C2:
                            y1 = C3
                        elif x2 == C1 and y2 == C2:
                            y2 = C3
                        elif x4 == C1 and y4 == C2:
                            y4 = C3
                        elif x5 == C1 and y5 == C2:
                            y5 = C3
                        elif x6 == C1 and y6 == C2:
                            y6 = C3
                        elif x7 == C1 and y7 == C2:
                            y7 = C3
                        elif x8 == C1 and y8 == C2:
                            y8 = C3
                        elif x9 == C1 and y9 == C2:
                            y9 = C3
                    elif y3 == C1 and x3 == C1:   
                        if x1 == C1 and y1 == C1:
                            y1 = C2
                        elif x2 == C1 and y2 == C1:
                            y2 = C2
                        elif x4 == C1 and y4 == C1:
                            y4 = C2
                        elif x5 == C1 and y5 == C1:
                            y5 = C2
                        elif x6 == C1 and y6 == C1:
                            y6 = C2
                        elif x7 == C1 and y7 == C1:
                            y7 = C2
                        elif x8 == C1 and y8 == C1:
                            y8 = C2
                        elif x9 == C1 and y9 == C1:
                            y9 = C2

                    elif y3 == C2 and x3 == C2:  
                        if x1 == C2 and y1 == C2:
                            y1 = C3
                        elif x2 == C2 and y2 == C2:
                            y2 = C3
                        elif x4 == C2 and y4 == C2:
                            y4 = C3
                        elif x5 == C2 and y5 == C2:
                            y5 = C3
                        elif x6 == C2 and y6 == C2:
                            y6 = C3
                        elif x7 == C2 and y7 == C2:
                            y7 = C3
                        elif x8 == C2 and y8 == C2:
                            y8 = C3
                        elif x9 == C2 and y9 == C2:
                            y9 = C3
                    elif y3 == C1 and x3 == C2:   
                        if x1 == C2 and y1 == C1:
                            y1 = C2
                        elif x2 == C2 and y2 == C1:
                            y2 = C2
                        elif x4 == C2 and y4 == C1:
                            y4 = C2
                        elif x5 == C2 and y5 == C1:
                            y5 = C2
                        elif x6 == C2 and y6 == C1:
                            y6 = C2
                        elif x7 == C2 and y7 == C1:
                            y7 = C2
                        elif x8 == C2 and y8 == C1:
                            y8 = C2
                        elif x9 == C2 and y9 == C1:
                            y9 = C2

                    elif y3 == C2 and x3 == C3:  
                        if x1 == C3 and y1 == C2:
                            y1 = C3
                        elif x2 == C3 and y2 == C2:
                            y2 = C3
                        elif x4 == C3 and y4 == C2:
                            y4 = C3
                        elif x5 == C3 and y5 == C2:
                            y5 = C3
                        elif x6 == C3 and y6 == C2:
                            y6 = C3
                        elif x7 == C3 and y7 == C2:
                            y7 = C3
                        elif x8 == C3 and y8 == C2:
                            y8 = C3
                        elif x9 == C3 and y9 == C2:
                            y9 = C3
                    elif y3 == C1 and x3 == C3:   
                        if x1 == C3 and y1 == C1:
                            y1 = C2
                        elif x2 == C3 and y2 == C1:
                            y2 = C2
                        elif x4 == C3 and y4 == C1:
                            y4 = C2
                        elif x5 == C3 and y5 == C1:
                            y5 = C2
                        elif x6 == C3 and y6 == C1:
                            y6 = C2
                        elif x7 == C3 and y7 == C1:
                            y7 = C2
                        elif x8 == C3 and y8 == C1:
                            y8 = C2
                        elif x9 == C3 and y9 == C1:
                            y9 = C2
        pygame.display.update()
def gameOver():
    gray = pygame.image.load('gray.png')
    font = pygame.font.SysFont("comicsansms",35)
    while true:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
        gameDisplay.blit(gray,(550,100))
        text = font.render('GAME OVER ',True,(160,20,82))
        gameDisplay.blit(text,(590,180))
        text = font.render('OUT OF MOVES',True,(160,20,82))
        gameDisplay.blit(text,(550,250))
        button('RESTART',550,430,200,60,red,green,gamePlay)
        button('MENU',600,330,150,60,red,green,gameIntro)
        pygame.display.update()

def targetNum():    
    font = pygame.font.SysFont("comicsansms",40)
    text = font.render('TARGET',True,(255,255,0))
    gameDisplay.blit(text,(630,300))
    text = font.render('1  2  3',True,(255,0,255))
    gameDisplay.blit(text,(650,350))
    text = font.render('4  5  6',True,(255,0,255))
    gameDisplay.blit(text,(650,400))
    text = font.render('7  8  ',True,(255,0,255))
    gameDisplay.blit(text,(650,450))
def targetAlpha():    
    font = pygame.font.SysFont("comicsansms",40)
    text = font.render('TARGET',True,(255,255,0))
    gameDisplay.blit(text,(630,300))
    text = font.render('A  B  C',True,(255,0,255))
    gameDisplay.blit(text,(650,350))
    text = font.render('D  E  F',True,(255,0,255))
    gameDisplay.blit(text,(650,400))
    text = font.render('G  H  ',True,(255,0,255))
    gameDisplay.blit(text,(650,450))
def targetNumAlpha():    
    font = pygame.font.SysFont("comicsansms",40)
    text = font.render('TARGET',True,(255,255,0))
    gameDisplay.blit(text,(630,300))
    text = font.render('1  A  2',True,(255,0,255))
    gameDisplay.blit(text,(650,350))
    text = font.render('B  3  C',True,(255,0,255))
    gameDisplay.blit(text,(650,400))
    text = font.render('4  D  ',True,(255,0,255))
    gameDisplay.blit(text,(650,450))
def button(msg,x,y,w,h,ic,ac,action = None):          
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.SysFont("comicsansms",60)
    
    if x+w >mouse[0]>x and y+h > mouse[1] >y:
        text = font.render(msg,True,ic)
        gameDisplay.blit(text,(x,y-10))
        if click[0]==1 and action != None:
             action()
    else:
        text = font.render(msg,True,ac)
        gameDisplay.blit(text,(x,y-10))
red = (255,0,0)
def gameIntro():
    global gameType
    gameType = '0'
    font = pygame.font.SysFont("comicsansms",150)
    bkk = pygame.image.load('main.png')
    while True:
        gameDisplay.fill((50,60,20))##(50,60,20)
        gameDisplay.blit(bkk,(400,160))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
        text = font.render('PUZZLE',True,(255,0,255))
        gameDisplay.blit(text,(150,-30))
        button('START',40,200,210,60,red,green,chooseGame)
        button('HELP ',70,300,150,60,red,green,instruct)
        button('EXIT',60,400,160,60,red,green,GameExit)
        pygame.display.update()
def background_crash():
    pygame.mixer.music.load('click sound.mp3')
    pygame.mixer.music.set_volume(2)
    pygame.mixer.music.play(1)
def instruct():   
    while True:
        gameDisplay.fill((50,60,20))#(50,60,20))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
        font = pygame.font.SysFont("comicsansms",60)
        text = font.render('INSTRUCTION ',True,(160,120,180))
        gameDisplay.blit(text,(200,0))
        font = pygame.font.SysFont("comicsansms",55)
        text = font.render('use left,up,down,right arrow ',True,(255,0,255))
        gameDisplay.blit(text,(40,80))
        text = font.render('           key to move a box          ',True,(255,0,255))
        gameDisplay.blit(text,(40,160))
        text = font.render('complete the puzzle within',True,(255,0,255))
        gameDisplay.blit(text,(40,240))
        text = font.render('                  100 moves',True,(255,0,255))
        gameDisplay.blit(text,(0,320))

        text = font.render('press home button anytime ',True,(255,0,255))
        gameDisplay.blit(text,(40,400))
        text = font.render('           to quit the game',True,(255,0,255))
        gameDisplay.blit(text,(0,480))
        button('BACK',630,520,155,60,red,green,gameIntro)
        pygame.display.update()

def chooseGame():   
    font = pygame.font.SysFont("comicsansms",90)
    while True:
        gameDisplay.fill((50,60,20))#(50,60,20))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
        text = font.render('DO YOU WANT TO',True,(255,0,255))
        gameDisplay.blit(text,(-5,10))
        text = font.render('PLAY',True,(255,0,255))
        gameDisplay.blit(text,(330,130))
        button('NUMBER PUZZLE ',200,280,490,60,red,green,numPuzzel)
        button('ALPHABET PUZZLE',160,405,540,60,red,green,alphaPuzzel)
        button('NUM-ALPHA PUZZLE',160,530,600,60,red,green,gamePlay)
        pygame.display.update()
def numPuzzel():
    global gameType
    gameType = 'numPuzzle'
    gamePlay()
def alphaPuzzel():
    global gameType
    gameType = 'alphaPuzzle'
    gamePlay()

def win():
    gray = pygame.image.load('gray.png')
    font = pygame.font.SysFont("comicsansms",35)
    while true:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                GameExit()
        gameDisplay.blit(gray,(550,100))
        text = font.render('   LEVEL  ',True,(160,20,82))
        gameDisplay.blit(text,(590,180))
        text = font.render('COMPELETE',True,(160,20,82))
        gameDisplay.blit(text,(570,250))
        button('RESTART',550,430,200,60,red,green,gamePlay)
        button('MENU',600,330,150,60,red,green,gameIntro)
        pygame.display.update()
def numResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9):
    if (x8==150 and y8==150 and x4==300 and y4==150 and x7==450 and y7==150 and x2==150 and y2==300 and x9==300 and y9==300 and x1==450 and y1==300 and x5==150 and y5==450 and x6==300 and y6==450):
        win()
def alphaResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9):
    if (x8==300 and y8==450 and x4==300 and y4==150 and x7==450 and y7==150 and x2==150 and y2==150 and x9==300 and y9==300 and x1==450 and y1==300 and x5==150 and y5==300 and x6==150 and y6==450):
        win()
def alphaNumResult(x1,x2,x4,x5,x6,x7,x8,y1,y2,y4,y5,y6,y7,y8,y9):
    if (x8==300 and y8==450 and x4==300 and y4==150 and x7==450 and y7==150 and x2==150 and y2==450 and x9==150 and y9==150 and x1==300 and y1==450 and x5==150 and y5==300 and x6==150 and y6==450):
        win()
gameIntro()
    
